﻿using ArmoireProjet.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ArmoireProjet.AppData.Services
{
    public interface ICategorieService
    {
        Task<List<Categorie>> GetAllCategoriesAsync();
        Task<Categorie> GetCategorieByIdAsync(int id);
        Task AddCategorieAsync(Categorie categorie);
        Task UpdateCategorieAsync(Categorie categorie);
        Task DeleteCategorieAsync(int id);
    }
}
