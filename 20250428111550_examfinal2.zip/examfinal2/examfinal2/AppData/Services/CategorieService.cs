﻿using ArmoireProjet.AppData;
using ArmoireProjet.Models;
using Microsoft.EntityFrameworkCore;

namespace ArmoireProjet.AppData.Services
{
    public class CategorieService : ICategorieService
    {
        private readonly AppDbContext _context;

        public CategorieService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Categorie>> GetAllCategoriesAsync() => await _context.Categories.ToListAsync();

        public async Task<Categorie> GetCategorieByIdAsync(int id) => await _context.Categories.FindAsync(id);

        public async Task AddCategorieAsync(Categorie categorie)
        {
            _context.Categories.Add(categorie);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateCategorieAsync(Categorie categorie)
        {
            _context.Categories.Update(categorie);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteCategorieAsync(int id)
        {
            var categorie = await _context.Categories.FindAsync(id);
            if (categorie != null)
            {
                _context.Categories.Remove(categorie);
                await _context.SaveChangesAsync();
            }
        }
    }
}
