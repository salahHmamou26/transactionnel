﻿using Microsoft.AspNetCore.Http;
using ArmoireProjet.Models;
using System.Text.Json;


namespace ArmoireProjet.AppData.Services
{
    public class PanierService : IPanierService
    {
        private readonly IHttpContextAccessor _http;

        public PanierService(IHttpContextAccessor http)
        {
            _http = http;
        }

        private const string PanierKey = "Panier";

        private List<PanierItem> LirePanier()
        {
            var data = _http.HttpContext!.Session.GetString(PanierKey);
            return data != null ? JsonSerializer.Deserialize<List<PanierItem>>(data)! : new List<PanierItem>();
        }

        private void SauverPanier(List<PanierItem> panier)
        {
            var data = JsonSerializer.Serialize(panier);
            _http.HttpContext!.Session.SetString(PanierKey, data);
        }

        public void AjouterProduit(Produit produit)
        {
            var panier = LirePanier();
            var item = panier.FirstOrDefault(p => p.ProduitId == produit.Id);
            if (item != null)
                item.Quantite++;
            else
                panier.Add(new PanierItem
                {
                    ProduitId = produit.Id,
                    Nom = produit.Nom,
                    Prix = produit.Prix,
                    ImageUrl = produit.ImageUrl,
                    Quantite = 1
                });

            SauverPanier(panier);
        }

        public void SupprimerProduit(int produitId)
        {
            var panier = LirePanier();
            var item = panier.FirstOrDefault(p => p.ProduitId == produitId);
            if (item != null)
                panier.Remove(item);

            SauverPanier(panier);
        }

        public void ModifierQuantite(int produitId, int quantite)
        {
            var panier = LirePanier();
            var item = panier.FirstOrDefault(p => p.ProduitId == produitId);
            if (item != null && quantite > 0)
                item.Quantite = quantite;

            SauverPanier(panier);
        }

        public List<PanierItem> GetPanier() => LirePanier();

        public decimal GetTotal() => LirePanier().Sum(p => p.Prix * p.Quantite);

        public void ViderPanier() => SauverPanier(new List<PanierItem>());
    }
}
