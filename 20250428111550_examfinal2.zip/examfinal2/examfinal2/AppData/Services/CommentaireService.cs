﻿using ArmoireProjet.Models;
using Microsoft.EntityFrameworkCore;

namespace ArmoireProjet.AppData.Services
{
    public class CommentaireService : ICommentaireService
    {
        private readonly AppDbContext _context;

        public CommentaireService(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddCommentaireAsync(Commentaire commentaire)
        {
            _context.Commentaires.Add(commentaire);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Commentaire>> GetCommentairesByProduitIdAsync(int produitId)
        {
            return await _context.Commentaires
                .Where(c => c.ProduitId == produitId && c.ParentCommentaireId == null)
                .Include(c => c.Replies)
                .ToListAsync();
        }
    }
}
