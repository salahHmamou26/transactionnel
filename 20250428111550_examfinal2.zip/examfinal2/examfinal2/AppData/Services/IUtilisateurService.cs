﻿using ArmoireProjet.Models;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ArmoireProjet.AppData.Services
{
    public interface IUtilisateurService
    {
        Task<Utilisateur?> AuthentifierAsync(string email, string motDePasse);
        Task<bool> EmailExisteAsync(string email);
        Task AjouterUtilisateurAsync(Utilisateur utilisateur);
        Task<List<Utilisateur>> GetTousLesUtilisateursAsync();
    }
}
