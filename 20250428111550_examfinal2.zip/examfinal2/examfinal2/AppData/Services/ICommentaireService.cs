﻿using ArmoireProjet.Models;

namespace ArmoireProjet.AppData.Services
{
    public interface ICommentaireService
    {
        Task AddCommentaireAsync(Commentaire commentaire);
        Task<List<Commentaire>> GetCommentairesByProduitIdAsync(int produitId);
    }
}
