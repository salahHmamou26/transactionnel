﻿using ArmoireProjet.Models;


namespace ArmoireProjet.AppData.Services
{
    public interface IPanierService
    {
        void AjouterProduit(Produit produit);
        void SupprimerProduit(int produitId);
        void ModifierQuantite(int produitId, int quantite);
        List<PanierItem> GetPanier();
        decimal GetTotal();
        void ViderPanier();
    }
}
