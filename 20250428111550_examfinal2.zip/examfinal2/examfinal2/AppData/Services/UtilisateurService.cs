﻿using ArmoireProjet.Models;
using Microsoft.EntityFrameworkCore;

namespace ArmoireProjet.AppData.Services
{
    public class UtilisateurService : IUtilisateurService
    {
        private readonly AppDbContext _context;

        public UtilisateurService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Utilisateur?> AuthentifierAsync(string email, string motDePasse)
        {
            return await _context.Utilisateurs
                .FirstOrDefaultAsync(u => u.Email == email && u.MotDePasse == motDePasse);
        }

        public async Task<bool> EmailExisteAsync(string email)
        {
            return await _context.Utilisateurs.AnyAsync(u => u.Email == email);
        }

        public async Task AjouterUtilisateurAsync(Utilisateur utilisateur)
        {
            _context.Utilisateurs.Add(utilisateur);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Utilisateur>> GetTousLesUtilisateursAsync()
        {
            return await _context.Utilisateurs.ToListAsync();
        }
    }
}
