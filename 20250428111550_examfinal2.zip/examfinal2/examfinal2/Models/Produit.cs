﻿using System.ComponentModel.DataAnnotations;

namespace ArmoireProjet.Models
{
    public class Produit
    {
        public int Id { get; set; }

        [Required]
        public string Nom { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public decimal Prix { get; set; }

        public string ImageUrl { get; set; }

        public int? CategorieId { get; set; }
        public Categorie? Categorie { get; set; }

    }
}
