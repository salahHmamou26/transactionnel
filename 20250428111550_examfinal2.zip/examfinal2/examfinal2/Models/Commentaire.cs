﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ArmoireProjet.Models
{
    public class Commentaire
    {
        public int Id { get; set; }

        [Required]
        public string Contenu { get; set; }

        public DateTime DateCreation { get; set; } = DateTime.Now;

        [Required]
        public string NomAuteur { get; set; } 

        public int ProduitId { get; set; }
        public Produit Produit { get; set; }

        
        public int? ParentCommentaireId { get; set; }
        public Commentaire ParentCommentaire { get; set; }

        public List<Commentaire> Replies { get; set; } = new List<Commentaire>();
    }
}
