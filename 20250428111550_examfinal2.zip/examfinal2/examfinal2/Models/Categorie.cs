﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace ArmoireProjet.Models
{
    public class Categorie
    {
        public int Id { get; set; }

        [Required]
        public string Nom { get; set; }

        
        public ICollection<Produit>? Produits { get; set; }
    }
}
