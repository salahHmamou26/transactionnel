﻿
    namespace ArmoireProjet.Models
    {
        public class PanierItem
        {
            public int ProduitId { get; set; }
            public string Nom { get; set; }
            public decimal Prix { get; set; }
            public string? ImageUrl { get; set; }
            public int Quantite { get; set; } = 1;
        }
    }


