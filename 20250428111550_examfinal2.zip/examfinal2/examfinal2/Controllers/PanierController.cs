﻿using Microsoft.AspNetCore.Mvc;
using ArmoireProjet.AppData.Services;
using ArmoireProjet.Models;

namespace ArmoireProjet.Controllers
{
    public class PanierController : Controller
    {
        private readonly IPanierService _panierService;
        private readonly IProduitService _produitService;

        public PanierController(IPanierService panierService, IProduitService produitService)
        {
            _panierService = panierService;
            _produitService = produitService;
        }

        public IActionResult Index()
        {
            var panier = _panierService.GetPanier();
            ViewBag.Total = _panierService.GetTotal();
            return View(panier);
        }

        public async Task<IActionResult> Ajouter(int id)
        {
            var produit = await _produitService.GetProduitByIdAsync(id);
            if (produit == null)
                return NotFound();

            _panierService.AjouterProduit(produit);
            return RedirectToAction("Index");
        }

        public IActionResult Supprimer(int id)
        {
            _panierService.SupprimerProduit(id);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult ModifierQuantite(int produitId, int quantite)
        {
            _panierService.ModifierQuantite(produitId, quantite);
            return RedirectToAction("Index");
        }

        public IActionResult Commander()
        {
            _panierService.ViderPanier();
            return View("Merci");
        }
        public IActionResult Paiement()
        {
            var panier = _panierService.GetPanier();
            if (!panier.Any())
                return RedirectToAction("Index");

            ViewBag.Total = _panierService.GetTotal();
            return View();
        }
        [HttpPost]
        public IActionResult Commander(string nom, string carte, string expiration, string cvv, string adresse, decimal montant)
        {
            
            _panierService.ViderPanier();
            ViewBag.Nom = nom;
            ViewBag.Montant = montant;
            return View("Merci");
        }

    }
}
