﻿using Microsoft.AspNetCore.Mvc;
using ArmoireProjet.Models;
using ArmoireProjet.AppData.Services;

namespace ArmoireProjet.Controllers
{
    public class CategorieController : Controller
    {
        private readonly ICategorieService _service;

        public CategorieController(ICategorieService service)
        {
            _service = service;
        }

        // GET: /Categorie
        public async Task<IActionResult> Index()
        {
            if (!EstConnecte())
                return RedirectToAction("Login", "Auth");

            var categories = await _service.GetAllCategoriesAsync();
            return View(categories);
        }

        // GET: /Categorie/Details/5
        public async Task<IActionResult> Details(int id)
        {
            if (!EstConnecte())
                return RedirectToAction("Login", "Auth");

            var categorie = await _service.GetCategorieByIdAsync(id);
            if (categorie == null)
                return NotFound();

            return View(categorie);
        }

        // GET: /Categorie/Create
        public IActionResult Create()
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            return View();
        }

        // POST: /Categorie/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Categorie categorie)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View(categorie);

            await _service.AddCategorieAsync(categorie);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Categorie/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            var categorie = await _service.GetCategorieByIdAsync(id);
            if (categorie == null)
                return NotFound();

            return View(categorie);
        }

        // POST: /Categorie/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Categorie categorie)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View(categorie);

            await _service.UpdateCategorieAsync(categorie);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Categorie/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            var categorie = await _service.GetCategorieByIdAsync(id);
            if (categorie == null)
                return NotFound();

            return View(categorie);
        }

        // POST: /Categorie/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            await _service.DeleteCategorieAsync(id);
            return RedirectToAction(nameof(Index));
        }


        
        private bool EstConnecte()
        {
            return HttpContext.Session.GetString("UserEmail") != null;
        }

      
        private bool EstAdmin()
        {
            return HttpContext.Session.GetString("UserRole") == "Admin";
        }
    }
}
