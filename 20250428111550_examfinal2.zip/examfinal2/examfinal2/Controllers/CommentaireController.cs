﻿using ArmoireProjet.Models;
using ArmoireProjet.AppData.Services;
using Microsoft.AspNetCore.Mvc;

namespace ArmoireProjet.Controllers
{
    public class CommentaireController : Controller
    {
        private readonly ICommentaireService _service;

        public CommentaireController(ICommentaireService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> Ajouter(int produitId, string contenu, int? parentCommentaireId)
        {
            if (string.IsNullOrWhiteSpace(contenu))
                return RedirectToAction("Details", "Produit", new { id = produitId });

            string nomAuteur = HttpContext.Session.GetString("UserRole") == "Admin" ? "Admin" : HttpContext.Session.GetString("UserEmail");

            var commentaire = new Commentaire
            {
                ProduitId = produitId,
                Contenu = contenu,
                ParentCommentaireId = parentCommentaireId,
                NomAuteur = nomAuteur
            };

            await _service.AddCommentaireAsync(commentaire);
            return RedirectToAction("Details", "Produit", new { id = produitId });
        }
    }
}
