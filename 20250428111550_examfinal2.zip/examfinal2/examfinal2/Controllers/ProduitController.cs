﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ArmoireProjet.Models;
using ArmoireProjet.AppData.Services;

namespace ArmoireProjet.Controllers
{
    public class ProduitController : Controller
    {
        private readonly IProduitService _produitService;
        private readonly ICategorieService _categorieService;
        private readonly ICommentaireService _commentaireService; //  Ajouté

        public ProduitController(IProduitService produitService, ICategorieService categorieService, ICommentaireService commentaireService)
        {
            _produitService = produitService;
            _categorieService = categorieService;
            _commentaireService = commentaireService;
        }

        // GET: /Produit
        public async Task<IActionResult> Index(int? categorieId)
        {
            if (!EstConnecte())
                return RedirectToAction("Login", "Auth");

            List<Produit> produits = categorieId.HasValue
                ? await _produitService.GetProduitsByCategorieAsync(categorieId.Value)
                : await _produitService.GetAllProduitsAsync();

            var categories = await _categorieService.GetAllCategoriesAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Nom", categorieId);

            return View(produits);
        }

        // GET: /Produit/Details/5
        public async Task<IActionResult> Details(int id)
        {
            if (!EstConnecte())
                return RedirectToAction("Login", "Auth");

            var produit = await _produitService.GetProduitByIdAsync(id);
            if (produit == null)
            {
                ViewBag.Erreur = "Ce produit n'existe pas.";
                return View();
            }

            
            var commentaires = await _commentaireService.GetCommentairesByProduitIdAsync(id);
            ViewBag.Commentaires = commentaires;

            return View(produit);
        }

        // GET: /Produit/Create
        public async Task<IActionResult> Create()
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            await RemplirCategories();
            return View();
        }

        // POST: /Produit/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Produit produit)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
            {
                await RemplirCategories(produit.CategorieId);
                return View(produit);
            }

            await _produitService.AddProduitAsync(produit);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Produit/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            var produit = await _produitService.GetProduitByIdAsync(id);
            if (produit == null)
                return NotFound();

            await RemplirCategories(produit.CategorieId);
            return View(produit);
        }

        // POST: /Produit/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Produit produit)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
            {
                await RemplirCategories(produit.CategorieId);
                return View(produit);
            }

            await _produitService.UpdateProduitAsync(produit);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Produit/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            var produit = await _produitService.GetProduitByIdAsync(id);
            if (produit == null)
                return NotFound();

            return View(produit);
        }

        // POST: /Produit/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (!EstAdmin())
                return RedirectToAction("Login", "Auth");

            await _produitService.DeleteProduitAsync(id);
            return RedirectToAction(nameof(Index));
        }

     
        private async Task RemplirCategories(int? selectedCategorieId = null)
        {
            var categories = await _categorieService.GetAllCategoriesAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Nom", selectedCategorieId);
        }

     
        private bool EstConnecte()
        {
            return HttpContext.Session.GetString("UserEmail") != null;
        }

     
        private bool EstAdmin()
        {
            return HttpContext.Session.GetString("UserRole") == "Admin";
        }
    }
}
