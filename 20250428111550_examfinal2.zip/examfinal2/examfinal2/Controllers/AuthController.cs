﻿using Microsoft.AspNetCore.Mvc;
using ArmoireProjet.Models;
using ArmoireProjet.AppData.Services;

namespace ArmoireProjet.Controllers
{
    public class AuthController : Controller
    {
        private readonly IUtilisateurService _utilisateurService;

        public AuthController(IUtilisateurService utilisateurService)
        {
            _utilisateurService = utilisateurService;
        }

        // GET: /Auth/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Auth/Login
        [HttpPost]
        public async Task<IActionResult> Login(string email, string motDePasse)
        {
            var utilisateur = await _utilisateurService.AuthentifierAsync(email, motDePasse);
            if (utilisateur == null)
            {
                ViewBag.Message = "Email ou mot de passe incorrect.";
                return View();
            }

            HttpContext.Session.SetString("UserEmail", utilisateur.Email);
            HttpContext.Session.SetString("UserRole", utilisateur.Role);

            return RedirectToAction("Index", "Produit");
        }

        // GET: /Auth/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: /Auth/Register
        [HttpPost]
        public async Task<IActionResult> Register(Utilisateur utilisateur)
        {
            if (await _utilisateurService.EmailExisteAsync(utilisateur.Email))
            {
                ViewBag.Message = "Email déjà utilisé.";
                return View(utilisateur);
            }

            utilisateur.Role = "Visiteur"; 
            await _utilisateurService.AjouterUtilisateurAsync(utilisateur);
            return RedirectToAction("Login");
        }

        // GET: /Auth/Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
